import Header from "./Header2/Header2";
import Sidebar2 from "./Sidebar2/Sidebar2";
export { Header, Sidebar2 };
